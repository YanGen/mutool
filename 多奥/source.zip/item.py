from mutool.reader import *
from mutool.constants import *
from mutool.writer import *
from mutool.date import *
from mutool.validate import *
import re,random
from urllib.parse import quote
import json
import string
from random import choice
from bs4 import BeautifulSoup
from concurrent.futures import ProcessPoolExecutor
from mutool.executer import *


mp = 10

validatePath("html")

req = requests.session()
req.headers = defaultStaticHeader

def suiji(length=15,chars=string.ascii_letters+string.digits):
    return ''.join([choice(chars) for i in range(length)])

def parser(kw):
    global req
    # kw = "箱子"
    sj = random.randint(1000000,1000000000)
    for page in range(1,mp+1):
        print("页",page)
        if page == 1:
            url = "http://taoke.jsgrain.com/search.php?type=form&ish=&kw=" + kw
        else:
            url = 'http://taoke.jsgrain.com/search/j8nCjcCo-{}.html'.format(page)
        html,req,status = getSource(url,session=req)
        html = html.replace('<script src="/','<script src="http://taoke.jsgrain.com/')
        html = html.replace('type="text/css" href="/','type="text/css" href="http://taoke.jsgrain.com/')
        reg = re.compile('/search/j8nCjcCo-(\d+)\.html').findall(html)
        for item in reg:
            html = html.replace('<a href="/search/j8nCjcCo-{}.html">{}</a>'.format(item,item),'<a href="./{}{}.html">{}</a>'.format(sj,item,item))
            html = html.replace('<a href="/search/j8nCjcCo-{}.html">下一页</a>'.format(item),'<a href="./{}{}.html">下一页</a>'.format(sj,item))
        writerToText("html/{}{}.html".format(sj,page),html,encoding="utf-8",append=False)

def main():
    source = open("source.txt",encoding='utf-8').read()
    for item in source.split("\n"):
        if item:
            item = item.strip()
            parser(item)

if __name__ == '__main__':
    main()